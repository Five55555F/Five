<?php

namespace JsonSchema;

abstract class Enum extends \MabeEnum\Enum
{
}
